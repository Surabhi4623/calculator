package com.example.surabhi.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Second extends AppCompatActivity {
    Button btn,btn2,btn3,btn4;
    EditText edit,edit1;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        btn = (Button) findViewById(R.id.btn);
        btn2=findViewById(R.id.btn2);
        btn3=findViewById(R.id.btn3);
        btn4=findViewById(R.id.btn4);
        edit = (EditText) findViewById(R.id.edit);
        edit1=(EditText)findViewById(R.id.edit1);
        text = (TextView) findViewById(R.id.text);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer answer = get_and_display();
                text.setText(Integer.toString(answer));
            }

        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer ans=multiply();
                text.setText(Integer.toString(ans));
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer sub= subtract();
                text.setText(Integer.toString(sub));
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer  div=divide();
                text.setText(Integer.toString(div));
            }
        });
    }

    public Integer multiply()
    {
        String one=edit.getText().toString();
        String two=edit1.getText().toString();
        int a = Integer.parseInt(one);
        int b = Integer.parseInt(two);
        int c = a * b;
        return c;
    }

    public Integer get_and_display() {
        String one = edit.getText().toString();
        String two= edit1.getText().toString();
        int a = Integer.parseInt(one);
        int b = Integer.parseInt(two);
        int c = a + b;
        return c;

    }
    public Integer subtract(){
        String one=edit.getText().toString();
        String two=edit1.getText().toString();
        int a =Integer.parseInt(one);
        int b=Integer.parseInt(two);
        int c=a-b;
        return c;

    }
    public Integer divide(){
        String one=edit.getText().toString();
        String two=edit1.getText().toString();
        int a =Integer.parseInt(one);
        int b =Integer.parseInt(two);
        int c =a /b;
        return c;
    }

}

